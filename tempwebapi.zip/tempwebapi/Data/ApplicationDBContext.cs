﻿using Microsoft.EntityFrameworkCore;
using WebMVCTEster.Models;

namespace WebAPITester.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Employee> Products { get; set; }
    }
}
