﻿using System.ComponentModel.DataAnnotations;

namespace WebMVCTEster.Models
{
    public class Employee
    {
        [Key]
        public int EmployeeId { get; set; }

        [Required]
        [StringLength(100)]
        public string EmployeeName { get; set; }

        [Required]
        [StringLength(50)]
        public string EmployeeCity { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime EmployeeDOB { get; set; }

        [Required]
        [StringLength(50)]
        public String EmployeeGender { get; set; }

        [Required]
        [Range(15000, 500000)]
        public decimal EmployeeSalary { get; set; }
    }
}
